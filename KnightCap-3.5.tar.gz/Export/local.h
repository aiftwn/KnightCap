/* this file is used to conveniently add local definitions */
#define LARGE_ETYPE 1
#define USE_PBRAIN 1
#define EVAL_SCALE (atanh(0.25)/PAWN_VALUE) /* tanh(1 pawn up) = 0.25 */
#if LEARN_EVAL
#define LARGE_ETYPE 1
#define RAMP_FACTOR (0.0)
/* for self play learning set USE_PBRAIN to 0. For ICS learning 
   set it to 1 */
#define USE_PBRAIN 1
#define SHORT_GAME 20
#define STORE_LEAF_POS 1
#define MAX_GAME_MOVES 600
#define EVAL_DIFF 0.05 /* max acceptable eval deviation 
			  between root and leaf (tanh1 - tanh2)*/
#define USE_SLIDING_CONTROL 1
#endif


#if TRIDGE
#define USE_SLIDING_CONTROL 1
#define POSITIONAL_FACTOR 1
#endif
