/*
  file: lut.h
*/

#ifndef LUT_H
#define LUT_H

typedef struct {
    unsigned char r, g, b;
} LUTENTRY;

#endif
