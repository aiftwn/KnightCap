/* the evaluation functions */

#include "includes.h"
#include "knightcap.h"

#define EVAL_ALL_DEPTH 1

#define USE_EVAL_SHORTCUT 1
#define EVAL_SHORTCUT_THRESHOLD (3*PAWN_VALUE)
#define EVAL_SHORTCUT_OFFSET (3*PAWN_VALUE)

#define HUNG_PINS 1

#define BOARD_CONTROL_FACTOR 1
#define PIECE_VALUE_FACTOR 1

#define BISHOP_PAIR 100
#define ATTACK_SHIFT 5
#define WEAK_PAWN_ATTACK_VALUE 64
#define UNSTOPPABLE_PAWN 3000

#define QUEEN_ADVANCE 50
#define DOUBLED_PAWN 120
#define CASTLE_BONUS 250
#define ROOK_ON_OPEN_FILE 100
#define ROOK_ON_HALF_OPEN_FILE 25
#define KNIGHT_OUTPOST 100
#define BISHOP_OUTPOST 50
#define WEAK_PAWN  125
#define CONNECTED_ROOKS 70
#define ODD_BISHOPS_PAWN_POS 20
#define NO_PAWNS 900
#define OPPOSITE_BISHOPS 400
#define PINNED_HUNG_PIECE 1100
#define TRAPPED_STEP 128
#define TRAPPED_VALUE 200
#define EARLY_QUEEN_MOVEMENT 100

#define BLOCKED_PASSED_PAWN 100
#define KING_PASSED_PAWN_SUPPORT 100
#define PASSED_PAWN_ROOK_ATTACK 150
#define PASSED_PAWN_ROOK_SUPPORT 150
#define CONNECTED_PASSED_PAWNS 200

#define TRADE_BONUS 0

#define PAWN_DEFENCE 150

#define OPENING_KING_ADVANCE 300
#define MID_KING_ADVANCE 100

#define BLOCKED_DPAWN 120
#define BLOCKED_EPAWN 120
#define BLOCKED_KNIGHT 95

#define USELESS_PIECE 40

#define DRAW_VALUE -10


#define NO_MATERIAL 1000
#define MATING_POSITION 3000

extern struct state *state;
static int debug;

/* this is the value of pawns on open files as they move up the board
   - it is doubled for passed pawns */
static const int pawn_advance[7] = {0,  1300, 800, 500, 300, 200, 200}; 

static unsigned char black_pawn_loc[8];
static unsigned char white_pawn_loc[8];

#define PAWN_LOC(player) (player>0?white_pawn_loc:black_pawn_loc)

static int pop_count[256];

static void init_eval_tables(void)
{
	static int initialised;
	int i;

	if (initialised) return;
	initialised = 1;
	
	for (i=0;i<256;i++) {
		int j, ret=0;
		for (j=0;j<8;j++)
			if (i & (1<<j))
				ret++;
		pop_count[i] = ret;
	}
}

static inline int pop_count16(uint32 x)
{
	return pop_count[(x)&0xFF] + pop_count[((x)>>8)&0xFF];
}

static inline int pop_count32(uint32 x)
{
	return pop_count16((x) & 0xFFFF) + pop_count16((x) >> 16);
}

/* this basically tries to answer the question "can one of the players
   profitably capture on that square, assuming there was something there
   to capture */
static int get_control(Position *b, uint32 topieces, int piece) 
{
	int nw, nb;
	uint32 mask;
	/* the following masks select pieces that are of lower than
	   value than a piece */
	static const uint32 masks[2*KING+1] = 
	{0xFFFE, 0xFFFC, 0xFFF0, 0xFF00, 0xFF00, 0, 
	 0, 
	 0, 0xFF000000, 0xFF000000, 0xFFF00000, 0xFFFC0000, 0xFFFE0000};

	if (!topieces) return 0;

	mask = masks[piece+KING];
	if (topieces & mask) 
		return -piece;

	nw = pop_count[(topieces >> 8) & 0xFF];
	nb = pop_count[(topieces >> 24) & 0xFF];
	if (nw != nb) return nw - nb;

	nw = pop_count[topieces & 0xFF];
	nb = pop_count[(topieces >> 16) & 0xFF];

	return (nw - nb);
}




static const int pawn_pos_value[NUM_SQUARES] = {
		0, 5, 0, 0, 0, 0, 0, 0,
		0, 5, 2, 0, 0, 0, 0, 0,
		0, 5, 0, 0, 0, 0, 0, 0,
		0, 2,10,70,45, 0, 0, 0,
		0, 2,10,75,45, 0, 0, 0,
		0,15,-9, 0, 0, 0, 0, 0,
		0,15,-2,-9, 0, 0, 0, 0,
		0,15, 0,-9, 0, 0, 0, 0,
};


/* this evaluates a pawn - its more valuable if its a passed
   pawn or on an open file. In those cases it gains value
   as it moves up the board */
static int eval_white_pawn(Position *b, int pi)
{
	PieceStruct *piece = b->pieces + pi;
	int ret=0;
	int x = XPOS(piece->pos);
	int y = YPOS(piece->pos);
	int advance = 0;
	int weak = 0;

	ret = pawn_pos_value[piece->pos];

	/* a pawn is weak if it isn't supported by a pawn and can't
	   move to a place where it is supported by a pawn */
	if (b->topieces[piece->pos] & WPAWN_MASK) 
		goto not_weak;

	if ((b->topieces[piece->pos+NORTH] & WPAWN_MASK) &&
	    abs(b->board[piece->pos+NORTH]) != PAWN)
		goto not_weak;

	if (y == 1 && !(b->topieces[piece->pos+NORTH] & BPAWN_MASK) &&
	    (b->topieces[piece->pos+2*NORTH] & WPAWN_MASK) &&
	    (abs(b->board[piece->pos+NORTH]) != PAWN) &&
	    (abs(b->board[piece->pos+2*NORTH]) != PAWN))
		goto not_weak;
	    
	if (debug)
		lprintf(0,"weak %s\n", posstr(piece->pos));
	weak = 1;

	ret -= WEAK_PAWN;

	/* if its on a half open file then its even weaker */
	if (black_pawn_loc[x] == 0)
		ret -= WEAK_PAWN;

	/* attacks on weak pawns are worth something */
	if ((b->topieces[piece->pos]>>16) & 0xFF)
		ret -= pop_count[(b->topieces[piece->pos]>>16) & 0xFF] * WEAK_PAWN_ATTACK_VALUE;
	
not_weak:

	if (black_pawn_loc[x] < y) {
		int n = 7-y;
		if (!weak) {
			advance = pawn_advance[n] / 4;
		}
		if ((x==0 || black_pawn_loc[x-1] <= y) &&
		    (x==7 || black_pawn_loc[x+1] <= y)) {
			Square wkpos = WHITEPIECES(b)[IKING].pos;
			Square bkpos = BLACKPIECES(b)[IKING].pos;

			advance += pawn_advance[n];

			if (YPOS(bkpos) >= y && abs(XPOS(bkpos) - x) <= 1)
				advance >>= 1;

			if (YPOS(wkpos) >= y && abs(XPOS(wkpos) - x) <= 1)
				advance += KING_PASSED_PAWN_SUPPORT;

			if (b->board[piece->pos+NORTH] < 0)
				advance -= BLOCKED_PASSED_PAWN;

			if (x != 0 && white_pawn_loc[x-1] &&
			    abs(y - white_pawn_loc[x-1]) <= 1) {
				advance += CONNECTED_PASSED_PAWNS;
			}

			if (x != 7 && white_pawn_loc[x+1] &&
			    abs(y - white_pawn_loc[x+1]) <= 1) {
				advance += CONNECTED_PASSED_PAWNS;
			}

			if ((b->topieces[piece->pos] & BKROOK_MASK) &&
			    XPOS(BLACKPIECES(b)[IKROOK].pos) == x &&
			    YPOS(BLACKPIECES(b)[IKROOK].pos) < y) {
				/* there is a black king rook 
				   behind our passed pawn */
				advance -= PASSED_PAWN_ROOK_ATTACK;
			}

			if ((b->topieces[piece->pos] & BQROOK_MASK) &&
			    XPOS(BLACKPIECES(b)[IQROOK].pos) == x &&
			    YPOS(BLACKPIECES(b)[IQROOK].pos) < y) {
				/* there is a black queen rook 
				   behind our passed pawn */
				advance -= PASSED_PAWN_ROOK_ATTACK;
			}

			if ((b->topieces[piece->pos] & WKROOK_MASK) &&
			    XPOS(WHITEPIECES(b)[IKROOK].pos) == x &&
			    YPOS(WHITEPIECES(b)[IKROOK].pos) < y) {
				/* there is a white king rook 
				   behind our passed pawn */
				advance += PASSED_PAWN_ROOK_SUPPORT;
			}

			if ((b->topieces[piece->pos] & WQROOK_MASK) &&
			    XPOS(WHITEPIECES(b)[IQROOK].pos) == x &&
			    YPOS(WHITEPIECES(b)[IQROOK].pos) < y) {
				/* there is a white queen rook 
				   behind our passed pawn */
				advance += PASSED_PAWN_ROOK_SUPPORT;
			}


			/* a special case - is it unstoppable? */
			if ((b->piece_mask & BLACK_MASK) == BKING_MASK) {
				int kpos = BLACKPIECES(b)[IKING].pos;
				int kmoves = imax(abs(XPOS(kpos) - x), 7-YPOS(kpos));
				int pmoves = 7-y;
				if (blacks_move(b)) kmoves--;
				if (kmoves > pmoves) {
 					ret += UNSTOPPABLE_PAWN;
					ret += pawn_advance[n];
					if (debug)
						lprintf(0,"unstoppable %s\n",posstr(piece->pos));
				}
			}
		}
		ret += advance;
	}

	if (white_pawn_loc[x] != y)
		ret -= DOUBLED_PAWN;

	if ((b->piece_mask & WBISHOP_MASK) == WKBISHOP_MASK) {
		if (!white_square(piece->pos)) ret += ODD_BISHOPS_PAWN_POS;
	} else if ((b->piece_mask & WBISHOP_MASK) == WQBISHOP_MASK) {
		if (white_square(piece->pos)) ret += ODD_BISHOPS_PAWN_POS;
	}

	return ret;
}

static int eval_black_pawn(Position *b, int pi)
{
	PieceStruct *piece = b->pieces + pi;
	int ret=0;
	int x = XPOS(piece->pos);
	int y = YPOS(piece->pos);
	int advance = 0;
	int weak = 0;

	ret = pawn_pos_value[mirror_square(piece->pos)];

	/* a pawn is weak if it isn't supported by a pawn and can't
	   move to a place where it is supported by a pawn */
	if (b->topieces[piece->pos] & BPAWN_MASK) 
		goto not_weak;

	if ((b->topieces[piece->pos+SOUTH] & BPAWN_MASK) &&
	    abs(b->board[piece->pos+SOUTH]) != PAWN)
		goto not_weak;

	if (y == 1 && !(b->topieces[piece->pos+SOUTH] & WPAWN_MASK) &&
	    (b->topieces[piece->pos+2*SOUTH] & BPAWN_MASK) &&
	    (abs(b->board[piece->pos+SOUTH]) != PAWN) &&
	    (abs(b->board[piece->pos+2*SOUTH]) != PAWN))
		goto not_weak;

	if (debug)
		lprintf(0,"weak %s\n", posstr(piece->pos));
	weak = 1;
	ret -= WEAK_PAWN;

	/* if its on a half open file then its even weaker */
	if (white_pawn_loc[x] == 0)
		ret -= WEAK_PAWN;

	/* attacks on weak pawns are worth something */
	if (b->topieces[piece->pos] & 0xFF)
		ret -= pop_count[b->topieces[piece->pos] & 0xFF] * WEAK_PAWN_ATTACK_VALUE;

 not_weak:

	if (white_pawn_loc[x] == 0 || white_pawn_loc[x] > y) {
		int n = y;
		if (!weak) {
			advance = pawn_advance[n] / 4;
		}
		if ((x==0 || white_pawn_loc[x-1]==0 ||
		     white_pawn_loc[x-1] >= y) &&
		    (x==7 || white_pawn_loc[x+1]==0 ||
		     white_pawn_loc[x+1] >= y)) {
			Square wkpos = WHITEPIECES(b)[IKING].pos;
			Square bkpos = BLACKPIECES(b)[IKING].pos;

			advance += pawn_advance[n];

			if (YPOS(wkpos) <= y && abs(XPOS(wkpos) - x) <= 1)
				advance >>= 1;

			if (YPOS(bkpos) <= y && abs(XPOS(bkpos) - x) <= 1)
				advance += KING_PASSED_PAWN_SUPPORT;

			if (YPOS(wkpos) <= y && abs(XPOS(wkpos) - x) <= 1)
				advance >>= 1;

			if (b->board[piece->pos+SOUTH] > 0) {
				advance -= BLOCKED_PASSED_PAWN;
			}

			if (x != 0 && black_pawn_loc[x-1] &&
			    abs(y - black_pawn_loc[x-1]) <= 1) {
				advance += CONNECTED_PASSED_PAWNS;
			}

			if (x != 7 && black_pawn_loc[x+1] &&
			    abs(y - black_pawn_loc[x+1]) <= 1) {
				advance += CONNECTED_PASSED_PAWNS;
			}

			if ((b->topieces[piece->pos] & WKROOK_MASK) &&
			    XPOS(WHITEPIECES(b)[IKROOK].pos) == x &&
			    YPOS(WHITEPIECES(b)[IKROOK].pos) > y) {
				/* there is a white king rook 
				   behind our passed pawn */
				advance -= PASSED_PAWN_ROOK_ATTACK;
			}

			if ((b->topieces[piece->pos] & WQROOK_MASK) &&
			    XPOS(WHITEPIECES(b)[IQROOK].pos) == x &&
			    YPOS(WHITEPIECES(b)[IQROOK].pos) > y) {
				/* there is a white queen rook 
				   behind our passed pawn */
				advance -= PASSED_PAWN_ROOK_ATTACK;
			}


			if ((b->topieces[piece->pos] & BKROOK_MASK) &&
			    XPOS(BLACKPIECES(b)[IKROOK].pos) == x &&
			    YPOS(BLACKPIECES(b)[IKROOK].pos) > y) {
				/* there is a black king rook 
				   behind our passed pawn */
				advance += PASSED_PAWN_ROOK_SUPPORT;
			}

			if ((b->topieces[piece->pos] & BQROOK_MASK) &&
			    XPOS(BLACKPIECES(b)[IQROOK].pos) == x &&
			    YPOS(BLACKPIECES(b)[IQROOK].pos) > y) {
				/* there is a black queen rook 
				   behind our passed pawn */
				advance += PASSED_PAWN_ROOK_SUPPORT;
			}


			/* a special case - is it unstoppable? */
			if ((b->piece_mask & WHITE_MASK) == WKING_MASK) {
				int kpos = WHITEPIECES(b)[IKING].pos;
				int kmoves = imax(abs(XPOS(kpos) - x), YPOS(kpos));
				int pmoves = y;
				if (whites_move(b)) kmoves--;
				if (kmoves > pmoves) {
 					ret += UNSTOPPABLE_PAWN;
					ret += pawn_advance[n];
					if (debug)
						lprintf(0,"unstoppable %s\n",posstr(piece->pos));
				}
			}
		}
		ret += advance;		
	}

	if (black_pawn_loc[x] != y)
		ret -= DOUBLED_PAWN;

	if ((b->piece_mask & BBISHOP_MASK) == BKBISHOP_MASK) {
		if (white_square(piece->pos)) ret += ODD_BISHOPS_PAWN_POS;
	} else if ((b->piece_mask & BBISHOP_MASK) == BQBISHOP_MASK) {
		if (!white_square(piece->pos)) ret += ODD_BISHOPS_PAWN_POS;
	}

	return ret;
}


/* these are adjustments for king position in the opening and
   ending - they try to encourage a central king in the ending */
static const int ending_kpos[8] = {-150, -70, 80,100,100,80, -70, -150};


/* the king likes to be near an edge at the start of the game and
   near the middle at the end */
static int eval_white_king(Position *b, int pi)
{
	PieceStruct *piece = b->pieces + pi;
	int ret=0;
	
	if (b->piece_mask & BQUEEN_MASK) {
		if (b->stage == OPENING) {
			if (YPOS(piece->pos) != 0)
				ret -= OPENING_KING_ADVANCE*YPOS(piece->pos);
		} if (b->stage == MIDDLE) {
			if (YPOS(piece->pos) != 0)
				ret -= MID_KING_ADVANCE*YPOS(piece->pos);
		}
	} else {
		ret += ending_kpos[XPOS(piece->pos)] +
			ending_kpos[YPOS(piece->pos)];
	}

	if (b->stage == ENDING)
		return ret;

	if (b->flags & WHITE_CASTLED) {
		ret += CASTLE_BONUS;
	} else if (!(b->flags & (WHITE_CASTLE_SHORT|WHITE_CASTLE_LONG))) {
		ret -= CASTLE_BONUS;
	}

	/* forget about pawn defence once the queens are off! */
	if (!(b->material_mask & BQUEEN_MASK))
		return ret;

	if (YPOS(piece->pos) == 0 && 
	    (XPOS(piece->pos) > 4 || (b->flags & WHITE_CASTLE_SHORT))) {
		if (b->board[F2] == PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[G2] == PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[H2] == PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[H3] == PAWN && b->board[G2] == PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[G3] == PAWN && b->board[H2] == PAWN &&
		    !(b->material_mask & BQBISHOP_MASK))
			ret += PAWN_DEFENCE;
		if (b->board[F3] == PAWN && b->board[G2] == PAWN &&
		    !(b->material_mask & BKBISHOP_MASK))
			ret += PAWN_DEFENCE;
	}

	if (YPOS(piece->pos) == 0 && XPOS(piece->pos) < 3) {
		if (b->board[A2] == PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[B2] == PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[C2] == PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[A3] == PAWN && b->board[B2] == PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[B3] == PAWN && b->board[A2] == PAWN &&
		    !(b->material_mask & BKBISHOP_MASK))
			ret += PAWN_DEFENCE;
		if (b->board[C3] == PAWN && b->board[B2] == PAWN &&
		    !(b->material_mask & BQBISHOP_MASK))
			ret += PAWN_DEFENCE;
	}

	return ret;
}


static int eval_black_king(Position *b, int pi)
{
	PieceStruct *piece = b->pieces + pi;
	int ret=0;
	
	if (b->piece_mask & WQUEEN_MASK) {
		if (b->stage == OPENING) {
			if (YPOS(piece->pos) != 7)
				ret -= OPENING_KING_ADVANCE*(7-YPOS(piece->pos));
		} if (b->stage == MIDDLE) {
			if (YPOS(piece->pos) != 7)
				ret -= MID_KING_ADVANCE*(7-YPOS(piece->pos));
		}
	} else {
		ret += ending_kpos[XPOS(piece->pos)] +
			ending_kpos[YPOS(piece->pos)];
	}

	if (b->stage == ENDING)
		return ret;

	if (b->flags & BLACK_CASTLED) {
		ret += CASTLE_BONUS;
	} else if (!(b->flags & (BLACK_CASTLE_SHORT|BLACK_CASTLE_LONG))) {
		ret -= CASTLE_BONUS;
	} 

	/* forget about pawn defence once the queens are off! */
	if (!(b->material_mask & WQUEEN_MASK))
		return ret;

	if (YPOS(piece->pos) == 7 && 
	    (XPOS(piece->pos) > 4 || (b->flags & BLACK_CASTLE_SHORT))) {
		if (b->board[F7] == -PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[G7] == -PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[H7] == -PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[H6] == -PAWN && b->board[G7] == -PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[G6] == -PAWN && b->board[H7] == -PAWN &&
		    !(b->material_mask & WQBISHOP_MASK))
			ret += PAWN_DEFENCE;
		if (b->board[F6] == -PAWN && b->board[G7] == -PAWN &&
		    !(b->material_mask & WKBISHOP_MASK))
			ret += PAWN_DEFENCE;
	}

	if (YPOS(piece->pos) == 7 && XPOS(piece->pos) < 3) {
		if (b->board[A7] == -PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[B7] == -PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[C7] == -PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[A6] == -PAWN && b->board[B7] == -PAWN)
			ret += PAWN_DEFENCE;
		if (b->board[B6] == -PAWN && b->board[A7] == -PAWN &&
		    !(b->material_mask & WKBISHOP_MASK))
			ret += PAWN_DEFENCE;
		if (b->board[C6] == -PAWN && b->board[B7] == -PAWN &&
		    !(b->material_mask & WQBISHOP_MASK))
			ret += PAWN_DEFENCE;
	}

	return ret;
}



static int eval_queen(Position *b, int pi)
{
	return 0;
}

static int eval_rook(Position *b, int pi)
{
	static const int pos_value[NUM_SQUARES] = {
		0, 0, 0, 0, 0, 0,200,50,
		0, 0, 0, 0, 0, 0,200,50,
		0, 0, 0, 0, 0, 0,200,50,
		0, 0, 0, 0, 0, 0,200,50,
		0, 0, 0, 0, 0, 0,200,50,
		0, 0, 0, 0, 0, 0,200,50,
		0, 0, 0, 0, 0, 0,200,50,
		0, 0, 0, 0, 0, 0,200,50,
	};

	PieceStruct *p = b->pieces + pi;
	int ret=0;

	if (p->p > 0)
		ret += pos_value[p->pos];
	else
		ret += pos_value[mirror_square(p->pos)];

	if (p->p > 0) {
		if (b->topieces[p->pos] & WROOK_MASK)
			ret += CONNECTED_ROOKS;
	} else {
		if (b->topieces[p->pos] & BROOK_MASK)
			ret += CONNECTED_ROOKS;
	}

	return ret;
}

static int eval_bishop(Position *b, int pi)
{
	PieceStruct *p = b->pieces + pi;
	int ret=0;
	int xray=0;
	PieceStruct *p2;
	static const int xray_bonus[5] = {0, 40, 90,120,130};
	int x = XPOS(p->pos);
	int y = YPOS(p->pos);

	/* bishops are good on outposts */
	if (p->p > 0) {
		if (y < 6 && y > 3 &&
		    (x == 0 || black_pawn_loc[x-1] <= y) &&
		    (x == 7 || black_pawn_loc[x+1] <= y)) {
			ret += BISHOP_OUTPOST;
			if (black_pawn_loc[x] > y) {
				ret += BISHOP_OUTPOST/2;
			}
		}
	} else {
		if (y > 1 && y < 4 &&
		    (x == 0 || white_pawn_loc[x-1] == 0 ||
		     white_pawn_loc[x-1] >= y) &&
		    (x == 7 || white_pawn_loc[x+1] == 0 ||
		     white_pawn_loc[x+1] >= y)) {
			ret += BISHOP_OUTPOST;
			if (white_pawn_loc[x] && white_pawn_loc[x] < y) {
				ret += BISHOP_OUTPOST/2;
			}
		}
	}

	/* bishops get a bonus for Xray attacks on kings, queens or rooks */
	p2 = &PIECES(b, -p->p)[IKING];
	if (capture_map[p->p+KING][p->pos][p2->pos])
		xray++;

	p2 = &PIECES(b, -p->p)[IQUEEN];
	if (p2->p && capture_map[p->p+KING][p->pos][p2->pos])
		xray++;

	p2 = &PIECES(b, -p->p)[IQROOK];
	if (p2->p && capture_map[p->p+KING][p->pos][p2->pos])
		xray++;

	p2 = &PIECES(b, -p->p)[IKROOK];
	if (p2->p && capture_map[p->p+KING][p->pos][p2->pos])
		xray++;

	ret += xray_bonus[xray];

	return ret;
}


static int eval_knight(Position *b, int pi)
{
	PieceStruct *p = b->pieces + pi;
	int ret=0;
	int x = XPOS(p->pos);
	int y = YPOS(p->pos);

	static int pos_value[NUM_SQUARES] = {
		-30,-20,-10, -5,  0,  5,-50,-70,
		-20,-10,  0,  0, 10, 20,  0,-30,
		-10,  0, 50, 50, 50, 50, 20, 10,
		 -5,  5, 30, 65, 65, 30, 25, 15,
		 -5,  5, 30, 65, 65, 30, 25, 15,
		-10,  0, 50, 50, 50, 50, 20, 10,
		-20,-10,  0,  0, 10, 20,  0,-30,
		-30,-20,-10, -5,  0,  5,-50,-70,
	};

	if (p->p > 0)
		ret += pos_value[p->pos];
	else
		ret += pos_value[mirror_square(p->pos)];

	/* knights are great on outposts */
	if (p->p > 0) {
		if (y < 6 && y > 3 &&
		    (x == 0 || black_pawn_loc[x-1] <= y) &&
		    (x == 7 || black_pawn_loc[x+1] <= y)) {
			ret += KNIGHT_OUTPOST;
			if (black_pawn_loc[x] > y) {
				ret += KNIGHT_OUTPOST/2;
			}			
		}
	} else {
		if (y > 1 && y < 4 &&
		    (x == 0 || white_pawn_loc[x-1] == 0 ||
		     white_pawn_loc[x-1] >= y) &&
		    (x == 7 || white_pawn_loc[x+1] == 0 ||
		     white_pawn_loc[x+1] >= y)) {
			ret += KNIGHT_OUTPOST;
			if (white_pawn_loc[x] && white_pawn_loc[x] < y) {
				ret += KNIGHT_OUTPOST/2;
			}
		}
	}

	return ret;
}


/* build a table of the most backward pawns in each file for each color */
static void build_pawn_loc(Position *b)
{
	int i;
	PieceStruct *p;
	
	memset(white_pawn_loc, 0, sizeof(white_pawn_loc));
	memset(black_pawn_loc, 0, sizeof(black_pawn_loc));

	p = &WHITEPIECES(b)[8];
	for (i=0;i<8;i++, p++) 
		if (p->p == PAWN) {
			int x = XPOS(p->pos);
			int y = YPOS(p->pos);
			if (white_pawn_loc[x] == 0 ||
			    white_pawn_loc[x] > y)
				white_pawn_loc[x] = y;
		}

	p = &BLACKPIECES(b)[8];
	for (i=0;i<8;i++, p++) 
		if (p->p == -PAWN) {
			int x = XPOS(p->pos);
			int y = YPOS(p->pos);
			black_pawn_loc[x] = imax(black_pawn_loc[x], y);
		}
}


static void estimate_game_stage(Position *b)
{
	int count;
	int last_stage = b->stage;

	count = pop_count[b->piece_mask & 0xFF] + 
		pop_count[(b->piece_mask >> 16) & 0xFF];

	if ((b->piece_mask & QUEEN_MASK) == QUEEN_MASK)
		count += 2;

	if (count <= 6) {
		b->stage = ENDING;
	} else if (count >= 16 && (b->flags & FLAG_CAN_CASTLE)) {
		b->stage = OPENING;
	} else {
		b->stage = MIDDLE;
	}

	if (last_stage != b->stage) {
		b->piece_change |= KING_MASK;
	}
}


/* try to discourage specific positional features - particularly in
   the opening */
static int specifics(Position *b)
{
	int ret = 0;

	/* blocking the e or d pawn is a bad idea */
	if (b->board[D3] && b->board[D2] == PAWN)
		ret -= BLOCKED_DPAWN;

	if (b->board[E3] && b->board[E2] == PAWN)
		ret -= BLOCKED_EPAWN;

	if (b->board[D6] && b->board[D7] == -PAWN)
		ret -= -BLOCKED_DPAWN;

	if (b->board[E6] && b->board[E7] == -PAWN)
		ret -= -BLOCKED_EPAWN;


	/* blocking in knights is a bad idea */
	if (b->board[C3] && b->board[B1] == KNIGHT)
		ret -= BLOCKED_KNIGHT;

	if (b->board[F3] && b->board[G1] == KNIGHT)
		ret -= BLOCKED_KNIGHT;

	if (b->board[C6] && b->board[B8] == -KNIGHT)
		ret -= -BLOCKED_KNIGHT;

	if (b->board[F6] && b->board[G8] == -KNIGHT)
		ret -= -BLOCKED_KNIGHT;

	/* pairs of bishops are good */
	if ((b->piece_mask & WBISHOP_MASK) == WBISHOP_MASK)
		ret += BISHOP_PAIR;

	if ((b->piece_mask & BBISHOP_MASK) == BBISHOP_MASK)
		ret -= BISHOP_PAIR;

	/* opposite bishops is drawish */
	if ((b->piece_mask & BISHOP_MASK) == (WKBISHOP_MASK | BKBISHOP_MASK) ||
	    (b->piece_mask & BISHOP_MASK) == (WQBISHOP_MASK | BQBISHOP_MASK)) {
		if (b->b_material > b->w_material + PAWN_VALUE/2)
			ret += OPPOSITE_BISHOPS;
		else if (b->w_material > b->b_material + PAWN_VALUE/2)
			ret -= OPPOSITE_BISHOPS;		
	}

	/* these are some specialist endgame things */
	if (b->w_material == 0 && b->piece_mask == b->material_mask) {
		int kpos = WHITEPIECES(b)[IKING].pos;

		ret -= NO_MATERIAL;

		if (b->piece_mask & BKBISHOP_MASK) {
			if (XPOS(kpos) < 3 && YPOS(kpos) < 3)
				ret -= MATING_POSITION;
			if (XPOS(kpos) > 4 && YPOS(kpos) > 4)
				ret -= MATING_POSITION;
		}
		if (b->piece_mask & BQBISHOP_MASK) {
			if (XPOS(kpos) < 3 && YPOS(kpos) > 4)
				ret -= MATING_POSITION;
			if (XPOS(kpos) > 4 && YPOS(kpos) < 3)
				ret -= MATING_POSITION;
		}
	}

	if (b->b_material == 0 && b->piece_mask == b->material_mask) {
		int kpos = BLACKPIECES(b)[IKING].pos;

		ret += NO_MATERIAL;

		if (b->piece_mask & WQBISHOP_MASK) {
			if (XPOS(kpos) < 3 && YPOS(kpos) < 3)
				ret += MATING_POSITION;
			if (XPOS(kpos) > 4 && YPOS(kpos) > 4)
				ret += MATING_POSITION;
		}
		if (b->piece_mask & WKBISHOP_MASK) {
			if (XPOS(kpos) < 3 && YPOS(kpos) > 4)
				ret += MATING_POSITION;
			if (XPOS(kpos) > 4 && YPOS(kpos) < 3)
				ret += MATING_POSITION;
		}
	}
	

	return ret;
}


static const int base_pos_value[NUM_SQUARES] = {
	2, 3, 4, 8, 8, 4, 3, 2,
	2, 4, 9,15,15, 9, 4, 2,
	4, 9,40,35,35,40, 9, 4,
	4, 9,40,60,60,40, 9, 4,
	4, 9,40,60,60,40, 9, 4,
	4, 9,40,35,35,40, 9, 4,
	2, 4, 9,15,15, 9, 4, 2,
	2, 3, 4, 8, 8, 4, 3, 2,
};

static int null_pos_value[NUM_SQUARES] = {
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
};

static int white_king_side[NUM_SQUARES] = {
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0,
	20,20,10,10, 0, 0, 0, 0,
	30,30,50,10, 0, 0, 0, 0,
	99,80,50,10, 0, 0, 0, 0,
	99,70,50,10, 0, 0, 0, 0,
};

static int black_king_side[NUM_SQUARES] = {
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0,10,10,20,20,
	0, 0, 0, 0,10,30,50,20,
	0, 0, 0, 0,10,50,80,99,
	0, 0, 0, 0,10,50,70,99,
};

static int white_queen_side[NUM_SQUARES] = {
	99,90,50,10, 0, 0, 0, 0,
	99,80,50,10, 0, 0, 0, 0,
	30,30,50,10, 0, 0, 0, 0,
	20,20,10,10, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
};

static int black_queen_side[NUM_SQUARES] = {
	0, 0, 0, 0,10,50,90,99,
	0, 0, 0, 0,10,50,80,99,
	0, 0, 0, 0,10,50,30,30,
	0, 0, 0, 0,10,10,20,20,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
};



static int new_pos_values;
static int *sq_p1, *sq_p2;

static void recalc_pos_values(Position *b)
{
	Square wkpos, bkpos;
	int flags = 0;

	wkpos = WHITEPIECES(b)[IKING].pos;
	bkpos = BLACKPIECES(b)[IKING].pos;

	sq_p1 = null_pos_value;
	sq_p2 = null_pos_value;

	if (XPOS(wkpos) > 3 && YPOS(wkpos) < 3) {
		sq_p1 = white_king_side;
		flags |= FLAG_WHITE_KINGSIDE;
	}

	if (XPOS(wkpos) < 3 && YPOS(wkpos) < 3) {
		sq_p1 = white_queen_side;
		flags |= FLAG_WHITE_QUEENSIDE;
	}

	if (XPOS(bkpos) > 3 && YPOS(bkpos) > 4) {
		sq_p2 = black_king_side;
		flags |= FLAG_BLACK_KINGSIDE;
	}

	if (XPOS(bkpos) < 3 && YPOS(bkpos) > 4) {
		sq_p2 = black_queen_side;
		flags |= FLAG_BLACK_QUEENSIDE;
	}

	if ((b->flags & FLAG_KQ_SIDE) == flags)
		return;

	new_pos_values = 1;

	b->flags &= ~FLAG_KQ_SIDE;
	b->flags |= flags;
}

static int board_control(Position *b)
{
	Square i, j;
	int control, total;
	int v;
	uint32 hung, attacking;
	uint32 topieces, oldflight, fchange, mchange;
	uint32 *top, *oldtop, *flight;
	Piece *oldboard;

	/* this is a mask which governs what piece can fly to a square
	   given the smallest attacker on the square, so for example, the 
	   0x00FC0000 entry means that any black piece except a queen
	   or king can fly to a square that is controlled by black if
	   the square is covered by a white rook */
	static const uint32 flight_mask[32] = {
		0x00FE0000, 0x00FE0000, 0x00FC0000, 0x00FC0000, 
		0x00F00000, 0x00F00000, 0x00F00000, 0x00F00000,
		0x00000000, 0x00000000, 0x00000000, 0x00000000,
		0x00000000, 0x00000000, 0x00000000, 0x00000000,

		0x00FE, 0x00FE, 0x00FC, 0x00FC, 
		0x00F0, 0x00F0, 0x00F0, 0x00F0,
		0x0000, 0x0000, 0x0000, 0x0000,
		0x0000, 0x0000, 0x0000, 0x0000
	};

	top = b->topieces;
	flight = b->flight;

	recalc_pos_values(b);

	if (b->oldb && (b->oldb->flags & FLAG_EVAL_DONE) && !new_pos_values) {
		oldtop = b->oldb->topieces;
		oldboard = b->oldb->board;
	} else {
		static uint32 dummy[64];
		static Piece dummy2[64];
		oldtop = dummy;
		oldboard = dummy2;
		b->board_control = 0;
		b->attacking_mask = 0;
		memset(b->control, 0, sizeof(b->control));
		memset(b->flight, 0, sizeof(b->flight));
		memset(b->mobility, 0, sizeof(b->mobility));
		memset(b->safe_mobility, 0, sizeof(b->safe_mobility));
		b->white_moves = b->black_moves = 0;
		new_pos_values = 0;
	}


	total = b->board_control;

	for (i=A1;i<=H8;i++) {
		if (top[i] == oldtop[i] && b->board[i] == oldboard[i]) {
			continue;
		}

		/* something has changed on the square - we need to recalculate
		   everything */

		oldflight = flight[i];
		topieces = top[i];
		control = get_control(b, topieces, b->board[i]);
		v = 0;

		/* now the trapped pieces stuff. we need to work out what 
		   pieces can flee to this square 

		   a square can be used as a flight square only if the 
		   piece would not be hung when it moves there. 

		   we use the flight mask to shortcut this calculation
		   */
		if (control > 0 && b->board[i] <= 0) {
			if (topieces & BLACK_MASK) {
				flight[i] = flight_mask[fl_one(topieces&BLACK_MASK)] & topieces;
			} else {
				flight[i] = topieces & WHITE_MASK;
			}
		} else if (control < 0 && b->board[i] >= 0) {
			if (topieces & WHITE_MASK) {
				flight[i] = flight_mask[fl_one(topieces&WHITE_MASK)] & topieces;
			} else {
				flight[i] = topieces & BLACK_MASK;
			}
		} else {
			flight[i] = 0;
		}

		flight[i] &= b->piece_mask;

		/* this xor tells us what pieces have changed in their
		   safe mobility */
		fchange = (oldflight ^ flight[i]) & b->piece_mask;

		while (fchange & WHITE_MASK) {
			j = ff_one(fchange & WHITE_MASK);
			fchange &= ~(1<<j);
			if (flight[i] & (1<<j)) {
				b->safe_mobility[j]++;
				b->white_moves++;
			} else {
				b->safe_mobility[j]--;
				b->white_moves--;
			}
		}

		while (fchange) {
			j = ff_one(fchange);
			fchange &= ~(1<<j);
			if (flight[i] & (1<<j)) {
				b->safe_mobility[j]++;
				b->black_moves++;
			} else {
				b->safe_mobility[j]--;
				b->black_moves--;
			}
		}

		/* this xor tells us what pieces have changed in their
		   mobility */
		mchange = (oldtop[i] ^ top[i]) & b->piece_mask;

		while (mchange & WHITE_MASK) {
			j = ff_one(mchange & WHITE_MASK);
			mchange &= ~(1<<j);
			if (top[i] & (1<<j)) {
				b->mobility[j]++;
			} else {
				b->mobility[j]--;
			}
		}

		while (mchange) {
			j = ff_one(mchange);
			mchange &= ~(1<<j);
			if (top[i] & (1<<j)) {
				b->mobility[j]++;
			} else {
				b->mobility[j]--;
			}
		}

		if (control == 0 && topieces == 0) {
			if (white_pawn_loc[XPOS(i)] &&
			    YPOS(i) <= white_pawn_loc[XPOS(i)])
				control++;
			if (black_pawn_loc[XPOS(i)] &&
			    YPOS(i) >= black_pawn_loc[XPOS(i)])
				control--;
		}

		/* the board control itself */
		if (control > 0) {
			v += base_pos_value[i] + sq_p1[i] + sq_p2[i];
		} else if (control < 0) {
			v -= base_pos_value[i] + sq_p1[i] + sq_p2[i];
		} 

		total += v - b->control[i];
		b->control[i] = v;
	}

	b->board_control = total;

	hung = 0;
	attacking = 0;

	for (i=1;i<16;i++) {
		if (!b->pieces[i].p) continue;
		j = b->pieces[i].pos;

		if (top[j] & BLACK_MASK) {
			attacking |= top[j] & BLACK_MASK;
			total -= pop_count[(top[j]>>16) & 0xFF] << ATTACK_SHIFT;
			if (b->control[j] < 0)
				hung |= (1<<i);
		}
	}

	for (i=17;i<32;i++) {
		if (!b->pieces[i].p) continue;
		j = b->pieces[i].pos;

		if (top[j] & WHITE_MASK) {
			attacking |= top[j] & WHITE_MASK;
			total += pop_count[top[j] & 0xFF] << ATTACK_SHIFT;
			if (b->control[j] > 0)
				hung |= (1<<i);
		}
	}

	attacking &= b->piece_mask;
	b->piece_change |= b->attacking_mask ^ attacking;
	b->hung_mask = hung;
	b->attacking_mask = attacking;

	if (debug)
		lprintf(0,"attacking_mask=%08x\n", b->attacking_mask);

#if 0
	if (squares_total % 1000 == 0) 
		lprintf(0,"sq/tot=%d\n",squares/squares_total);
#endif

	return total;
}


static int empty_line(Position *b, int sq1, int sq2)
{
	int dir, dx, dy;

	dx = XPOS(sq1) - XPOS(sq2);
	dy = YPOS(sq1) - YPOS(sq2);

	dir = 0;
	if (dy > 0) 
		dir += SOUTH;
	else if (dy < 0) 
		dir += NORTH;

	if (dx > 0) 
		dir += WEST;
	else if (dx < 0) 
		dir += EAST;

	sq1 += dir;

	while (sq1 != sq2) {
		if (b->board[sq1]) return 0;
		sq1 += dir;
	}

	return 1;
}


static int eval_hung(Position *b)
{
	int i, ret=0;
	uint32 hung = b->hung_mask;
	uint32 pinned_check;
	uint32 attacker;

	static const hung_value[17] = 
	{0, 90, 200, 200, 250, 300, 300, 300, 300, 
	 300, 300, 300, 300, 300, 300, 300, 300};

	if (debug)
		lprintf(0,"hung=%08x\n", hung);

	pinned_check = 0;

	if (whites_move(b)) {
		if (hung & WHITE_MASK)
			ret -= hung_value[pop_count16(hung & WHITE_MASK)];
		if (hung & BLACK_MASK)
			ret += hung_value[pop_count16(hung >> 16) + 1];

		while (hung & WHITE_MASK) {
			i = ff_one(hung & WHITE_MASK);
			hung &= ~(1<<i);
  			if (b->topieces[b->pieces[i].pos] &
				       (b->sliding_mask & BLACK_MASK))
			    pinned_check |= (1<<i);
		}

		while (hung) {
			i = ff_one(hung);
			hung &= ~(1<<i);
			if (b->topieces[b->pieces[i].pos] & 
				       (b->sliding_mask & WHITE_MASK))
			    pinned_check |= (1<<i);
		}
	} else {
		if (hung & WHITE_MASK)
			ret -= hung_value[pop_count16(hung & WHITE_MASK) + 1];
		if (hung & BLACK_MASK)
			ret += hung_value[pop_count16(hung >> 16)];

		while (hung & 0xFFFF) {
			i = ff_one(hung & 0xFFFF);
			hung &= ~(1<<i);
			if (b->topieces[b->pieces[i].pos] & 
				       (b->sliding_mask & BLACK_MASK))
			    pinned_check |= (1<<i);
		}

		while (hung) {
			i = ff_one(hung);
			hung &= ~(1<<i);
			if (b->topieces[b->pieces[i].pos] & 
				       (b->sliding_mask & WHITE_MASK))
			    pinned_check |= (1<<i);
		}
	}

	/* only worry about pins on pieces */
	pinned_check &= b->piece_mask;
			
#if HUNG_PINS
	/* now check is any hung pieces are also pinned - if they are
           then its particularly nasty! */
	while (pinned_check & 0xFFFF) {
		int kpos = WHITEPIECES(b)[IKING].pos;
		int qpos = WHITEPIECES(b)[IQUEEN].pos;

		i = ff_one(pinned_check & 0xFFFF);
		pinned_check &= ~(1<<i);
		
		attacker = b->topieces[b->pieces[i].pos] & 
			(b->sliding_mask & BLACK_MASK);

		while (attacker) {
			int j = ff_one(attacker);
			PieceStruct *p = &b->pieces[j];
			attacker &= ~(1<<j);

			/* only some sorts of pins are really
                           dangerous. Currently only look for king and
                           queen pins */
			if (capture_map[p->p+KING][p->pos][kpos] &&
			    empty_line(b, b->pieces[i].pos, kpos))
				ret -= PINNED_HUNG_PIECE;

			if (capture_map[p->p+KING][p->pos][qpos] &&
			    empty_line(b, b->pieces[i].pos, qpos))
				ret -= PINNED_HUNG_PIECE;
		}
	}

	while (pinned_check) {
		int kpos = BLACKPIECES(b)[IKING].pos;
		int qpos = BLACKPIECES(b)[IQUEEN].pos;

		i = ff_one(pinned_check);
		pinned_check &= ~(1<<i);
		
		attacker = b->topieces[b->pieces[i].pos] & 
			(b->sliding_mask & WHITE_MASK);

		while (attacker) {
			int j = ff_one(attacker);
			PieceStruct *p = &b->pieces[j];
			attacker &= ~(1<<j);

			/* only some sorts of pins are really
                           dangerous. Currently only look for king and
                           queen pins */
			if (capture_map[p->p+KING][p->pos][kpos] &&
			    empty_line(b, b->pieces[i].pos, kpos))
				ret += PINNED_HUNG_PIECE;

			if (capture_map[p->p+KING][p->pos][qpos] &&
			    empty_line(b, b->pieces[i].pos, qpos))
				ret += PINNED_HUNG_PIECE;
		}
	}
#endif

	return ret;
}


static int mobility_fn(Position *b, int pi)
{
	int mobility;
	int ret;

	static const int mobility_threshold[KING+1] = {0, 0, 6, 5, 4, 6, 0};

	static const int mobility_table[KING+1][10] = 
	{
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{-160, -150, -140, -100, -80, 0, 60, 80, 100, 120},
		{-130, -125, -120, -115, -80, 0, 40, 50, 60, 70},
		{-120, -110, -100, -50, 10, 20, 30, 40, 50, 60},
		{-200, -30, 0, 0, 0, 0, 0, 0, 0, 0}};

	static const int safe_mobility_table[KING+1][10] = 
	{
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{-80, -50, 0, 0, 0, 0, 0, 0, 0, 0},
		{-80, -50, 0, 0, 0, 0, 0, 0, 0, 0},
		{-80, -40, 0, 0, 0, 0, 0, 0, 0, 0},
		{-300, -250, -50, 0, 0, 0, 0, 0, 0, 0},
		{-200, -50, 0, 0, 0, 0, 0, 0, 0, 0}};

	mobility = b->mobility[pi];
	if (mobility >= 10) {
		mobility = 9;
	}

	ret = mobility_table[abs(b->pieces[pi].p)][mobility];

	if (b->mobility[pi] < mobility_threshold[abs(b->pieces[pi].p)] &&
	    !(b->attacking_mask & (1<<pi)))
		ret -= USELESS_PIECE;

	mobility = b->safe_mobility[pi];
	if (mobility >= 10) {
		mobility = 9;
	}

	ret += safe_mobility_table[abs(b->pieces[pi].p)][mobility];

	if (b->safe_mobility[pi] == 0) {
		if (b->pieces[pi].p > 0) {
			ret -= TRAPPED_STEP * YPOS(b->pieces[pi].pos);
		} else {
			ret -= TRAPPED_STEP * (7-YPOS(b->pieces[pi].pos));
		}
		if (b->hung_mask & (1<<pi)) {
			ret *= 2;
		}
	}

	return ret;
}

static int piece_values(Position *b)
{
	int v;
	int i;
	typedef int (*PieceFunction)();
	uint32 piece_change;
	int total;

	static struct {
		PieceFunction fn;
		float factor;
	} piece_functions[2*KING+1] = {
		{eval_black_king, 0},
		{eval_queen, 0},
		{eval_rook, 0},
		{eval_bishop, 0},
		{eval_knight, 0},
		{eval_black_pawn, 0},
		{NULL, 0},
		{eval_white_pawn, 0},
		{eval_knight, 0},
		{eval_bishop, 0},
		{eval_rook, 0},
		{eval_queen, 0},
		{eval_white_king, 0},
	};

	piece_change = b->piece_change;

	if ((piece_change & b->material_mask) == b->material_mask) {
		memset(b->piece_values, 0, sizeof(b->piece_values));
		b->piece_value = 0;
	}

	total = b->piece_value;

	for (i=0;i<32;i++) {
		if (!b->pieces[i].p) continue;
		if (!(piece_change & (1<<i)) &&
		    b->oldb && 
		    b->oldb->safe_mobility[i] == b->safe_mobility[i] &&
		    b->oldb->mobility[i] == b->mobility[i])
			continue;

		v = piece_functions[b->pieces[i].p + KING].fn(b, i);
		if (b->piece_mask & (1<<i))
			v += mobility_fn(b, i);
		if (i >= 16)
			v = -v;

		total += (v - b->piece_values[i]);
		b->piece_values[i] = v;
	}

	if (debug) {
		lprintf(0,"white pvalues:  \n");
		for (i=0;i<16;i++)
			if (b->pieces[i].p)
				lprintf(0,"%+3d ", b->piece_values[i]);
			else
				lprintf(0,"*** ");
		lprintf(0,"\n");
		lprintf(0,"black pvalues: \n");
		for (i=16;i<32;i++)
			if (b->pieces[i].p)
				lprintf(0,"%+3d ", -b->piece_values[i]);
			else
				lprintf(0,"*** ");
		lprintf(0,"\n");

		lprintf(0,"white mobility: \n");
		for (i=0;i<8;i++)
			if (b->pieces[i].p)
				lprintf(0,"%2d ", b->mobility[i]);
			else
				lprintf(0,"** ");
		lprintf(0,"\n");
		lprintf(0,"black mobility: \n");
		for (i=16;i<24;i++)
			if (b->pieces[i].p)
				lprintf(0,"%2d ", b->mobility[i]);
			else
				lprintf(0,"** ");
		lprintf(0,"\n");
	}
			


	b->piece_change = 0;
	b->piece_value = total;

	return total;
}

/* this is called only when there are no pawns on the board */
static int check_material(Position *b, int ret0)
{
	int ret = ret0;

	if (b->material_mask == b->piece_mask) {
		/* queen and king vs queen and king is probably a draw */
		if (b->w_material == QUEEN_VALUE && b->b_material == QUEEN_VALUE) {
			ret = draw_value(b) * 2;
			return ret - ret0;
		}

		/* king and rook vs king and rook is almost always a draw */
		if (b->w_material == ROOK_VALUE && b->b_material == ROOK_VALUE) {
			ret = draw_value(b) * 2;
			return ret - ret0;
		}
	}

	if ((b->material_mask & WHITE_MASK) == (b->piece_mask & WHITE_MASK) && 
	    b->w_material <= BISHOP_VALUE) {
		/* white has insufficient material to mate */
		ret = imin(ret, 0);
	}

	if ((b->material_mask & BLACK_MASK) == (b->piece_mask & BLACK_MASK) && 
	    b->b_material <= BISHOP_VALUE) {
		/* black has insufficient material to mate */
		ret = imax(ret, 0);
	}

	if (ret == 0 && ret0 != 0) {
		b->flags |= FLAG_ACCEPT_DRAW;
		if (debug)
			lprintf(0,"will accept draw\n");
	} else {
		b->flags &= ~FLAG_ACCEPT_DRAW;
	}

	if (ret == 0)
		ret = draw_value(b);

	/* push it nearer a draw as the fifty move mark approaches */
	if (ret != 0 && b->fifty_count > 20) {
		ret = ((128 - (b->fifty_count-20)) * ret) / 128;
	}

	if (ret == 0 && ret0 != 0) {
		ret = draw_value(b);
	}

#if TRADE_BONUS
	if (ret > PAWN_VALUE && 
	    b->w_material >= b->b_material + (PAWN_VALUE-20)) {
		/* encourage piece trading but not pawn trading */
		ret += (16-pop_count32(b->piece_mask)) * TRADE_BONUS;
		ret -= (16-pop_count32(b->material_mask & ~b->piece_mask)) * TRADE_BONUS;
	}

	if (ret < -PAWN_VALUE && 
	    b->b_material >= b->w_material + (PAWN_VALUE-20)) {
		/* encourage piece trading but not pawn trading */
		ret -= (16-pop_count32(b->piece_mask)) * TRADE_BONUS;
		ret += (16-pop_count32(b->material_mask & ~b->piece_mask)) * TRADE_BONUS;
	}
#endif

	return ret - ret0;
}


int draw_value(Position *b)
{
	if (state->computer > 0)
		return DRAW_VALUE;

	return -(DRAW_VALUE);
}

int eval(Position *b, Eval testv, int depth)
{
	int ret, v;
	int player = next_to_play(b);
	int material;

	init_eval_tables();

	if (b->oldb && !(b->oldb->flags & FLAG_EVAL_DONE)) {
		eval(b->oldb, testv, EVAL_ALL_DEPTH);
	}

	material = b->w_material - b->b_material;

	if (debug)
		lprintf(0,"w_material=%d b_material=%d\n",
			b->w_material, b->b_material);
	
	if (material > MAX_MATERIAL)
		material = MAX_MATERIAL;

	if (material < -MAX_MATERIAL)
		material = -MAX_MATERIAL;

	if (testv == INFINITY) {
		b->piece_change = b->material_mask;
		b->oldb = NULL;
	} else if (depth >= EVAL_ALL_DEPTH) {
		b->piece_change = b->material_mask;
	} 
#if USE_EVAL_SHORTCUT
	else if (b->oldb) {
		ret = (material+b->positional_value) * player;

		if (ret > testv+EVAL_SHORTCUT_THRESHOLD) {
			ret -= EVAL_SHORTCUT_OFFSET;
			return ret; 
		}
#if 0
		if (ret < testv-EVAL_SHORTCUT_THRESHOLD) {
			ret += EVAL_SHORTCUT_OFFSET;
			v = eval(b, testv, EVAL_ALL_DEPTH);
			lprintf(2,"alpha cutoff ret=%d testv=%d v=%d\n", ret, testv);
			if (v >= testv) {
				lprintf(0,"alpha error ret=%d testv=%d v=%d\n", ret, testv, v);
			}
			return ret; 
		}
#endif
	}
#endif

	ret = 0;

	estimate_game_stage(b);

	if (debug)
		lprintf(0,"game stage=%d\n", b->stage);

	build_pawn_loc(b);

	v = board_control(b) * BOARD_CONTROL_FACTOR;
	ret += v;
	if (debug)
		lprintf(0,"board control = %d\n", v);

	v = eval_hung(b);
	ret += v;
	if (debug)
		lprintf(0,"hung = %d\n", v);

	v = piece_values(b) * PIECE_VALUE_FACTOR;
	ret += v;
	if (debug)
		lprintf(0,"piece values = %d\n", v);

	v = specifics(b);
	ret += v;
	if (debug)
		lprintf(0,"specifics = %d\n", v);

	b->positional_value = ret * POSITIONAL_FACTOR;

	b->positional_value += check_material(b, material + b->positional_value);

	if (debug)
		lprintf(0,"pos value = %d\n", b->positional_value);

	ret = material + b->positional_value;

	if (debug)
		lprintf(0,"eval = %d\n", ret);

	b->flags |= FLAG_EVAL_DONE;

	return ret * player;
}


int eval1(Position *b, Eval testv, int depth)
{
	int ret1, ret2;
	Position b1, b2;

	b1 = (*b);
	b2 = (*b);

	ret1 = eval1(b, testv, depth);
	ret2 = eval1(&b1, INFINITY, depth);

	if (abs(ret1 - ret2) > 10) {
		lprintf(0,"\nret1 = %d ret2 = %d\n",
			ret1, ret2);
		debug = 1;

		(*b) = b2;
		b1 = b2;

		if (b->oldb) {
			print_board(b->oldb);
			print_board(b);
		}

		ret1 = eval1(b, testv, depth);
		ret2 = eval1(&b1, INFINITY, depth);
		
		debug = 0;
	}

	return ret1;
}


void eval_debug(Position *b)
{
	debug = 1;

	regen_moves(b);

	lprintf(0,"white_moves=%d black_moves=%d\n",
		b->white_moves, b->black_moves);

	eval(b, INFINITY, MAX_DEPTH);
	
	debug = 0;
}


void eval_speed(Position *b, int loops)
{
	int t, i;

	t = gettime();

	for (i=0;i<loops;i++)
		eval(b, INFINITY, MAX_DEPTH);

	t = gettime() - t;

	lprintf(0,"%d full eval calls in %d secs - %g eval/sec\n",
		loops, t, loops/(double)t);
}

