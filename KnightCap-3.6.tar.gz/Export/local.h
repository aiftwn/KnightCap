/* this file is used to conveniently add local definitions */
#ifndef PI
#define PI (3.141592653)
#endif
#define LARGE_ETYPE 1
#define USE_STATIC_PAWN_VALUE 0
#define EVAL_SCALE (atanh(0.25)/STATIC_PAWN_VALUE) /* tanh(1 pawn up) = 0.25 */
#define USE_PBRAIN 1
#if LEARN_EVAL
#define STORE_LEAF_POS 1
#define RAMP_FACTOR (0.0)
#define SHORT_GAME 20
#define MAX_GAME_MOVES 600
#define EVAL_DIFF 0.05 /* max acceptable eval deviation 
			  between root and leaf (tanh1 - tanh2)*/
#define USE_SLIDING_CONTROL 1
#endif


#if TRIDGE
#define USE_SLIDING_CONTROL 1
#define POSITIONAL_FACTOR 1
#endif
