#include <stdio.h>

#define PARAM1 "/* IPAWN_POS */"
#define PARAM2 "IPAWN_POS"
#define NUM_PARAMS 64
#define FIRST 0
#define LAST 0

main()
{
	char name[100];
	char line[400];
	int stage, i, j, coeff;
	FILE *infile;
	FILE *outfile;

	
	for (stage = 0; stage < 3; stage++) {
		sprintf(name, "../SAVE/%s%d", PARAM2, stage);
		outfile = (FILE *)fopen(name, "w");
		for (i=FIRST; i<=LAST; i++) {
			fprintf(outfile, "%d ", i);
			sprintf(name, "/usr/local/chess/SAVE/large_coeffs%d.h", i);
			infile = (FILE *)fopen(name, "r");
			for (j=0; j<=stage; j++) {
				while (!feof(infile)) {
					fgets(line, 400, infile);
					if (strstr(line, PARAM1))
						break;
				}
			}
			if (NUM_PARAMS==1) {
				char *p = strstr(line, "*/ ");
				p += strlen("*/ ");
				sscanf(p, "%d", &coeff);
				fprintf(outfile, "%d\n", coeff);
				fflush(outfile);
			} else {
				for (j=0; j<NUM_PARAMS; j++) {
					fscanf(infile, "%d,", &coeff);
					fprintf(outfile, "%d ", coeff);
				}
				fprintf(outfile, "\n");
			}
			fclose(infile);
		}
		
		fclose(outfile);
	}
}
		
