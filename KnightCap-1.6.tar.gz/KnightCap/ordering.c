/* move ordering code */
#include "includes.h"
#include "knightcap.h"

#define NUM_CUTOFFS 4

static unsigned history[NUM_SQUARES][NUM_SQUARES];
static Move last_cutoff[MAX_DEPTH][NUM_CUTOFFS];


void order_clear(int num_moves)
{
	static int last_num;
	int x,y, delta;

	if (last_num == num_moves)
		return;

	delta = imax(num_moves - last_num, 0);
	last_num = num_moves;

	for (x=A1;x<=H8;x++)
		for (y=A1;y<=H8;y++)
			history[x][y] >>= (delta+1);

	if (delta >= MAX_DEPTH)
		return;

	memmove(last_cutoff, &last_cutoff[delta], 
                sizeof(last_cutoff) - delta*sizeof(last_cutoff[0]));
}


void cutoff_hint(Position *b, Move *move, int depth, int ply)
{
	int i;

	if (ply < MAX_DEPTH && !same_move(move, &last_cutoff[ply][0])) {
		for (i=NUM_CUTOFFS-1;i>=1;i--)
			last_cutoff[ply][i] = last_cutoff[ply][i-1];
		last_cutoff[ply][0] = (*move);
	}

	depth += 0;
	if (depth < 0) depth = 0;
	history[move->from][move->to] += (1 << depth);
}

static int order_fn(Position *b, Move *m, int ply)
{
	int ret = 0;
        int i;

        if (ply < MAX_DEPTH) {
                for (i=0;i<NUM_CUTOFFS;i++)
                        if (m->from == last_cutoff[ply][i].from &&
                            m->to == last_cutoff[ply][i].to)
                                ret += (10000000 >> (i+1));
        }

	if (b->last_dest == m->to) {
		return 1000*1000 - abs(b->board[m->from]);
	}

	return ret + history[m->from][m->to];
}

void order_moves(Position *b, Move *moves, int n, int ply)
{
	int m;
	int priority[MAX_MOVES];

	for (m=0;m<n;m++)
		priority[m] = order_fn(b, &moves[m], ply);

	sort_moves(moves, priority, n);
}

