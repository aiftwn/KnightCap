/* this contains all the code the the hash tables (transposition tables) */
#include "includes.h"
#include "knightcap.h"

int hash_hits, hash_misses;
static unsigned hash_tag;

#if APLINUX
static unsigned num_cells;
static unsigned cell;
#endif

#ifndef HASH_TABLE_BITS
#define HASH_TABLE_BITS 19
#endif
#define HASH_TABLE_SIZE (1<<HASH_TABLE_BITS)
#define HASH2_MASK(x) (x)

#define NLEVEL 2

/* note that experiments show that 24 bits of hash2 occasionally gives
   a collision (maybe one per game on the AP+?). 25 isn't really
   enough. 32 is really needed! */

#define PAR_HASH_LEVEL -1

static struct hash_entry *white_hash_table, *black_hash_table;

#define DEPTH_HIGH 31
#define DEPTH_LOW 0

static int initialised;

static void hash_reset_stats(void)
{
	hash_misses = hash_hits = 0;
}

void hash_reset(void)
{
	int i;
	if (!initialised) return;

	for (i=0;i<HASH_TABLE_SIZE;i++) {
		white_hash_table[i].depth = DEPTH_LOW;
		black_hash_table[i].depth = DEPTH_LOW;
	}
}


void init_hash_table(void)
{
	int size;

	hash_reset_stats();

	if (initialised) return;
	initialised = 1;

	size = HASH_TABLE_SIZE*sizeof(white_hash_table[0]);

	white_hash_table = (struct hash_entry *)malloc(size);
	black_hash_table = (struct hash_entry *)malloc(size);

	printf("hash table size %d at %p %p\n", 
	       size*2, white_hash_table, black_hash_table);

	hash_reset();
#if APLINUX
	num_cells = getncel();
	cell = getcid();
#endif
}


int check_hash(Position *b, 
	       int depth, Eval testv, Eval *v)
{
	struct hash_entry *t;
	uint32 hashindex = (b->hash1 & (HASH_TABLE_SIZE-1));

#if NLEVEL
	hashindex &= ~(NLEVEL - 1);
#endif

	if (whites_move(b))
		t = &white_hash_table[hashindex];
	else
		t = &black_hash_table[hashindex];

#if APLINUX
	if (depth > PAR_HASH_LEVEL) {
		int get_flag = 0;
		int cid = (b->hash1 >> HASH_TABLE_BITS) % num_cells;
		get(cid, &b->h_entry, sizeof(*t), t, &get_flag, NULL);
		amcheck(&get_flag, 1);
	} else {
		b->h_entry = (*t);
	}
	t = &b->h_entry;
#endif
	
#if NLEVEL
	{
		int j;
		for (j=0;j<NLEVEL;j++, t++)
			if (t->hash2 == HASH2_MASK(b->hash2) && 
			    t->depth >= depth) break;
		if (j == NLEVEL) {
			hash_misses++;
			return 0;
		}
	}
#else
	if (t->hash2 != HASH2_MASK(b->hash2) || t->depth < depth) {
		hash_misses++;
		return 0;
	}
#endif

	if (t->high < testv || t->low >= t->high) {
		hash_hits++;
		(*v) = t->high;
		return 1;
	}

	if (t->low >= testv) {
		hash_hits++;
		(*v) = t->low;
		return 1;
	}

	hash_misses++;
	return 0;
}


void insert_hash(Position *b,
		 int depth, Eval testv, Eval evaluation)
{
	struct hash_entry *t;
	uint32 hashindex = (b->hash1 & (HASH_TABLE_SIZE-1));
#if APLINUX
	struct hash_entry *t1;
	int cid;
#endif

#if NLEVEL
	hashindex &= ~(NLEVEL - 1);
#endif

	if (whites_move(b))
		t = &white_hash_table[hashindex];
	else
		t = &black_hash_table[hashindex];

#if APLINUX
	t1 = t;

	t = &b->h_entry;
#endif

	if (t->tag == hash_tag) {
#if NLEVEL
		int j, k;
		for (j=0;j<NLEVEL;j++, t++)
			if (t->depth <= depth) break;
		if (j == NLEVEL) return;
		for (k=NLEVEL-(j+1); k>0; k--)
			t[k] = t[k-1];
#else
		if (t->depth > depth)
			return;
#endif
	}

	t->tag = hash_tag;
	
	if (depth < DEPTH_LOW)
		depth = DEPTH_LOW;

	if (depth > DEPTH_HIGH)
		depth = DEPTH_HIGH;
		
	if (testv == INFINITY) {
		t->high = t->low = evaluation;
		t->depth = depth;
		t->hash2 = HASH2_MASK(b->hash2);		
	} else if (t->hash2 == HASH2_MASK(b->hash2) &&
		   depth == t->depth) {
		/* its a refinement */
		if (evaluation < testv) {
			t->high = evaluation;
		} else {
			t->low = evaluation;
		} 
	} else {
		if (evaluation < testv) {
			t->high = evaluation;
			t->low = -INFINITY;
		} else {
			t->low = evaluation;
			t->high = INFINITY;
		}
		
		t->depth = depth;
		t->hash2 = HASH2_MASK(b->hash2);
	}

#if APLINUX
	if (depth > PAR_HASH_LEVEL) {
		cid = (b->hash1 >> HASH_TABLE_BITS) % num_cells;
		put(cid, t, sizeof(*t), t1, NULL, NULL, 0);
	} else {
		(*t1) = (*t);
	}
#endif
}

void hash_change_tag(int tag)
{
	hash_tag = (tag & 1) ^ 1;
}

char *hashstats(void)
{
	static char ret[30];
	sprintf(ret, "hash=%d%%", 
		(100*hash_hits)/(hash_misses+hash_hits+1));
	return ret;
}



